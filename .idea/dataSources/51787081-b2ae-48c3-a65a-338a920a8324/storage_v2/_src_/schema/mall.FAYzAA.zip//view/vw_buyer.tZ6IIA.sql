create definer = root@localhost view vw_buyer as
select `a`.`id` AS `id`, `a`.`name` AS `name`
from (`mall`.`company` `a`
         join `mall`.`s_basedict` `b` on (((`b`.`colname` = 'company_type') and (`a`.`company_type` = `b`.`code`))))
where ((`a`.`status` = 3) and (`b`.`name` in ('医院', '连锁药店', '药房', '诊所', '个人')));

