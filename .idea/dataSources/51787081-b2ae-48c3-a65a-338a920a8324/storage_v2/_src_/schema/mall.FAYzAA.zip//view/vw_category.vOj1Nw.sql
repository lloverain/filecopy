create definer = root@localhost view vw_category as
select `a`.`id`                                                       AS `id`,
       concat_ws(',', `d`.`name`, `c`.`name`, `b`.`name`, `a`.`name`) AS `分类`,
       concat_ws(',', `d`.`id`, `c`.`id`, `b`.`id`, `a`.`id`)         AS `分类id`,
       `a`.`sort`                                                     AS `sort`
from (((`mall`.`category` `a` left join `mall`.`category` `b` on (((`a`.`parent_id` = `b`.`id`) and (`b`.`status` = 3)))) left join `mall`.`category` `c` on (((`b`.`parent_id` = `c`.`id`) and (`b`.`status` = 3))))
         left join `mall`.`category` `d` on (((`c`.`parent_id` = `d`.`id`) and (`b`.`status` = 3))))
where (`a`.`status` = 3)
order by `a`.`sort`;

